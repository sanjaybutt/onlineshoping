<?php

require(__DIR__ . '/../model/dbquery.php');


class ShoppingCart {
    private $dataFunctions;

    public function indexAction() {
        echo 'Admin Index Action';
    }

    public function __construct($link) {
        $this->dataFunctions = new DataFunctions($link);
    }

    public function calculateTotal($name) {
        $cartItems = $this->dataFunctions->getCartItems('cart', $name);
        $total = 0;
        foreach ($cartItems as $item) {
            $qty = $item['qty'];
            $amount = intval($item['prize']);
            $total += $qty * $amount;
        }
        return ['cartItems' => $cartItems, 'total' => $total];
    }
    

    public function getAllData() {
        return $this->dataFunctions->getAlldata('admins');
    }

    public function getViewOrder($name) {
        return $this->dataFunctions->getViewOrder('cart', $name);
    }

    public function getProduct($proid) {
        return $this->dataFunctions->getParticularProduct('admins', $proid);
    }
}

// Usage:
$shoppingCart = new ShoppingCart($link);
$result = $shoppingCart->calculateTotal('shopping_cart'); 
$cartItems = $result['cartItems'];
$total = $result['total'];
$alldata = $shoppingCart->getAllData();
$rows = $shoppingCart->getViewOrder($name);
$products = $shoppingCart->getProduct($proid);
?>

