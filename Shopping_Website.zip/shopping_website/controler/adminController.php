
<?php
require(__DIR__ . '/../model/dbquery.php');


class Admin {
    private $dataFunctions;

    public function indexAction() {
        echo 'Admin Index Action';
    }
    public function __construct($link) {
        $this->dataFunctions = new DataFunctions($link);
    }

    public function getProductData() {
        return $this->dataFunctions->getalldatas('admins');
    }

    public function getParticularProduct($usid) {
        return $this->dataFunctions->getPaticulaproduct('admins', $usid);
    }

    public function getUserData() {
        return $this->dataFunctions->getuserdata('userdata');
    }

    public function getOrderData() {
        return $this->dataFunctions->getorderdata('orderdetails');
    }
}


$databaseManager = new Admin($link);
$productdata = $databaseManager->getProductData();
$particulardata = $databaseManager->getParticularProduct($usid);
$userdata = $databaseManager->getUserData();
$orderdata = $databaseManager->getOrderData();
?>
