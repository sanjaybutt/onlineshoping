<?php

require(__DIR__ . '/../model/dbquery.php');

class ActionHandler {
    private $dataFunctions;


    public function __construct($link) {
        $this->dataFunctions = new DataFunctions($link);
    }

    public function handleAction($action) {
        switch ($action) {
            case 'create':
                $this->handleUserCreation();
                break;
            case 'Login':
                $this->handleUserLogin();
                break;
            case 'Resetpassword':
                $this->dataFunctions->resetPassword(); 
                break;
            case 'forgotpassword':
                $this->dataFunctions->forgotPassword(); 
                break;
            case 'store':
                $this->handleAdminProduct(); 
                break;
            case 'add':
                $this->dataFunctions->addToCart(); 
                break;
            case 'delete':
                $this->dataFunctions->deleteItem(); 
                break;
            case 'deleteproduct':
                $this->dataFunctions->deleteProduct(); 
                break;
            case 'userdata':
                $this->dataFunctions->fetchUserData(); 
                break;
            case 'update':
                $this->dataFunctions->updateProduct(); 
                break;
            default:
                echo "Unknown action";
                break;
        }
    }
    private function handleUserCreation() {
     
        $firstname = $lastname = $username = $password = "";
        $firstnameErr = $lastnameErr = $usernameErr = $passwordErr = "";

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (empty($_POST["firstname"])) {
                $firstnameErr = "First name is required";
            } else {
                $firstname = $this->test_input($_POST["firstname"]);
              
            }
            if (empty($_POST["lastname"])) {
                $lastnameErr = "lastname is required";
            } else {
                $lastname = $this->test_input($_POST["lastname"]);
              
            }
            
            if (empty($_POST["username"])) {
                $usernameErr = "username is required";
            } else {
                $username= $this->test_input($_POST["username"]);
              
            }
            if (empty($_POST["password"])) {
                $passwordErr = "password is required";
            } else {
                $password= $this->test_input($_POST["password"]);
              
            }
           
            if (empty($firstnameErr) && empty($lastnameErr) && empty($usernameErr) && empty($passwordErr)) {
               
                $this->dataFunctions->createUser($firstname, $lastname, $username, $password);
            }
        }
    }
     
    private function handleUserLogin() {
       
        $username = $password = "";
        $usernameErr = $passwordErr = "";

    
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
            if (empty($_POST["username"])) {
                $usernameErr = "Username is required";
                header('Location: ../view/user/register?error1=' . urlencode($usernameErr));
            } else {
                $username = $this->test_input($_POST["username"]);
            }
    
            if (empty($_POST["password"])) {
                $passwordErr = "Password is required";
                header('Location: ../view/user/register?error=' . urlencode($passwordErr));
            } else {
                $password = $this->test_input($_POST["password"]);
            }
            if(empty($_POST["username"])&& empty($_POST["password"]))
            {

               $invalid = "username and password fields are empty.";
                
                header('location:../view/user/register?error2=' . urlencode($invalid ));
           
            }
    
            if (empty($usernameErr) && empty($passwordErr)) {
               
                $this->dataFunctions->login($username, $password);

               
            }  

        }
    }

    private function handleAdminProduct(){


      
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            
            $name = $detail = $prize = $category = "";
            $name_err = $detail_err = $prize_err = $category_err = "";
        
          
            if (empty($_POST["name"])) {
                $name_err = "Please enter product name.";
            } else {
                $name = $this->test_input($_POST["name"]);
            }
        
            
            if (empty($_POST["detail"])) {
                $detail_err = "Please enter product description.";
            } else {
                $detail = $this->test_input($_POST["detail"]);
            }
        
            
            if (empty($_POST["prize"])) {
                $prize_err = "Please enter product price.";
            } else {
                $prize = $this->test_input($_POST["prize"]);
                
                if (!is_numeric($prize)) {
                    $prize_err = "Please enter a valid price.";
                }
            }
        
          
            if (empty($_POST["category"])){
                $category_err = "Please enter category ID.";
            } else {
                $category = $this->test_input($_POST["category"]);
              
                if (!is_numeric($category)) {
                    $category_err = "Please enter a valid category ID.";
                }
            }
        
           
            if (empty($name_err) && empty($detail_err) && empty($prize_err) && empty($category_err)) {
               
                 
                $this->dataFunctions->addProduct($name,$detail,$prize,$category );
               
            }
        }
  
        

    }
    private function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
}



if (isset($_REQUEST['submit']) && !empty($_REQUEST['submit'])) {

    $actionHandler = new ActionHandler($link);
    $actionHandler->handleAction($_REQUEST['submit']);
} else {
    echo "No action specified";
}


?>
