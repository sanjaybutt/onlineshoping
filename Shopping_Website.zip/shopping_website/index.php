


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sara</title>
    <link rel="stylesheet" href="view/css/style3.css">
    <link rel="stylesheet" href="view/css/style2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

   <div class="container">
   <header>
<h2>Sɑɾɑ ƒɑSҺıᴏꞃ</h2>
<ul div class="navi">
<li> <div class="username"><h3 style="color:white;"><?php echo"$user"  ?></h3></div></li>
<li><a href="view/user/checkpoint"><i class="fa-solid fa-bag-shopping fa-lg" style="color: #121212;"></i></a></li>
<li><a href="view/user/register"><i class="fa-solid fa-user" style="color: #0a0a0a;"></i></a></li>
<li><a href="view/user/logout">logout</a></li>

</ul>
</div>


</header>
<navi>

<ul  class="nav">
<li><a href="view/user/men">𝖬𝖾𝗇</a></li>
<li><a href="view/user/women">𝖶𝗈𝗆𝖾𝗇</a></li>
</ul>

</navi>

<div class="main">
<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="view/image/Entry-Banner-web_07052023fo.jpg"  style="width:100%;height:400px">
 
</div>
<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="view/image/peppy-colors-web_280324f.jpg"  style="width:100%;height:400px">
 
</div>
<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img  src="view/image/Shoppers-Stop-Web-Banner_1840x500_300424c.jpg" style="width:100%;height:400px">
 
</div>
<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="view/image/Timeless-Monochrome-web_280324f.jpg"  style="width:100%;height:400px">
 
</div>

<script>
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  
  slides[slideIndex-1].style.display = "block";  
  
  setTimeout(showSlides, 3000); // Change image every 2 seconds
}
</script>
</div>
<main>
<div class="left">
<img src="view/image/ANd,-forever-new-web_7430sd.jpg"  style="width:100%">

</div>
<div class="center">
<img src="view/image/biba,-globaldesi-web - 2024-03 - 13-w.jpg" style="width:100%" >

</div>
<div class="right">
<img src="view/image/kraus,-levis-web_150224d.jpg"  style="width:100%">

</div>

<div class="edge">
<img src="view/image/web.jpg"  style="width:100%">

</div>




</main>
<div class="textshow" style="text-align:center;color:#AF7AC5 "><h1>𝔹𝔼𝕊𝕋 𝗢𝗙 𝗔𝗟𝗟</h1></div>
<div class="textshow1" style="text-align:center;color:black "><h1>𝙴𝙽𝙹𝙾𝚈 ₹𝟻𝟶𝟶 𝙾𝙵𝙵 | 𝚄𝚂𝙴 𝙲𝙾𝙳𝙴:𝚅𝙰𝙲𝙰𝚈𝟻𝟶𝟶</h1></div>

<div class="show1" ><img src="view/image/Crowd-Favourites-web_47447f.jpg"  style="width:100%"></div>
<main>
<div class="left">
<img src="view/image/Budget Store Web-Shirts - 2024-0304004.jpg"  style="width:100%">

</div>
<div class="center">
<img src="view/image/Budget Store Web-Indianwear -  - 2024-04 - 25 - new-.jpg" style="width:100%" >

</div>
<div class="right">
<img src="view/image/Budget Store Web-T-Shirts -  - -208924-04 - 25 - new-.jpg"  style="width:100%">

</div>

<div class="edge">
<img src="view/image/Budget Store Web-Bottomwear -  -  - 2024-04 - 25 - new-.jpg"  style="width:100%">

</div>




</main>
<footer>
    <img src="view/image/website-footer-design.jpg" style="width:100%">
</footer>
</div>
</body>
</html>
