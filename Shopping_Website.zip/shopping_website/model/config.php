<?php

class DB {
    private $host = 'localhost';
    private $username = 'root';
    private $password = 'novalnet';
    private $database = 'shopping1';
    private $con;

    // Constructor to establish connection
    public function __construct() {
        $this->con = new mysqli($this->host, $this->username, $this->password);
        if ($this->con->connect_error) {
            die('Connection error: ' . $this->con->connect_error);
        }
        $this->createDatabase();
        $this->con->select_db($this->database);
        $this->createTables();
    }

   
    private function createDatabase() {
        $sql = "CREATE DATABASE IF NOT EXISTS $this->database";
        if ($this->con->query($sql) !== TRUE) {
            echo "Error creating database: " . $this->con->error . "<br>";
        }
    }

   
    private function createTables() {
        $tables = array(
            "CREATE TABLE IF NOT EXISTS userdata (
                id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                fname VARCHAR(30) NOT NULL,
                lname VARCHAR(30) NOT NULL,
                username VARCHAR(50),
                setPass VARCHAR(255)
            )",
            "CREATE TABLE IF NOT EXISTS forgetmails(
                id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50)
            )",
            "CREATE TABLE IF NOT EXISTS admins(
                id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                pname VARCHAR(30) NOT NULL,
                pimage VARCHAR(500),
                description VARCHAR(50),
                prize VARCHAR(255),
                categoryid VARCHAR(255)
            )",
            "CREATE TABLE IF NOT EXISTS cart(
                id INT(6),
                pname VARCHAR(30) NOT NULL,
                pimage VARCHAR(500),
                prize VARCHAR(255),
                size1 VARCHAR(255),
                qty VARCHAR(255),
                userid VARCHAR(255)
            )",
            "CREATE TABLE IF NOT EXISTS orderdetails(
                id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
                fullname VARCHAR(30) NOT NULL,
                email VARCHAR(500),
                phone VARCHAR(255),
                addressuser VARCHAR(255),
                city VARCHAR(255),
                states VARCHAR(255),
                zip VARCHAR(255),
                country VARCHAR(255),
                cardnumber VARCHAR(255),
                expiry VARCHAR(255),
                cvv VARCHAR(255),
                userid VARCHAR(255)
            )"
        );

        foreach ($tables as $table) {
            if ($this->con->query($table) !== TRUE) {
                echo "Error creating table: " . $this->con->error . "<br>";
            }
        }
    }

   
    public function getConnection() {
        return $this->con;
    }
}


$db = new DB();
$link = $db->getConnection();
