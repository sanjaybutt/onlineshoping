



 



<?php
session_start();
require("config.php");

$name=isset($_SESSION['userid']) ? $_SESSION['userid'] : '';
$user=isset($_SESSION['username']) ? $_SESSION['username'] : '';


class DataFunctions extends DB {
    private $link;

    public function __construct($link) {
        $this->link = $link;
    }

    public function createUser() {
       
        $firstname = htmlspecialchars(strip_tags(trim($_REQUEST['firstname'])));
        $lastname = htmlspecialchars(strip_tags(trim($_REQUEST['lastname'])));
        $username = htmlspecialchars(strip_tags(trim($_REQUEST['username'])));
        $password = (strip_tags($_REQUEST['password']));
        
     
        $hashpassword = md5($password);
    
     
        $query = "INSERT INTO userdata (fname, lname, username, setPass) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($this->link, $query);
    
        
        mysqli_stmt_bind_param($stmt, "ssss", $firstname, $lastname, $username, $hashpassword);
    
       
        $result = mysqli_stmt_execute($stmt);
    
       
        if ($result) {
            header('location:../view/user/register');
        } else {
            echo mysqli_error($this->link);
        }
    
        mysqli_stmt_close($stmt);
    }
    
   

    public function login() {
        
        $username = mysqli_real_escape_string($this->link, $_REQUEST['username']);
        $pass = mysqli_real_escape_string($this->link, $_REQUEST['password']);
        
        
        $hashpassword = md5($pass);
    
       
        $query = "SELECT * FROM userdata WHERE username=? AND setPass=?";
        $stmt = mysqli_prepare($this->link, $query);
        
      
        mysqli_stmt_bind_param($stmt, "ss", $username, $hashpassword);
        
      
        mysqli_stmt_execute($stmt);
        
       
        $result = mysqli_stmt_get_result($stmt);
        
        if ($result) {
            $num_rows = mysqli_num_rows($result);
            if ($num_rows > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    session_start();
                    $_SESSION['userid'] = $row['id'];
                    $_SESSION['username'] = $row['fname'];
                    header('location:../view/user/index1?success=1');
                    exit; 
                }
            } else {
                header('location:../view/user/register?error=1');
                exit; 
            }
        } else {
            echo "Error: " . mysqli_error($this->link);
        }
    }
    
   
        public function getuserdata($table) {
            $query = "SELECT * from $table";
            $result = mysqli_query($this->link, $query);
            $res = []; 
            if (mysqli_num_rows($result) > 0) {
                $res = mysqli_fetch_all($result, MYSQLI_ASSOC);
            }
            return $res;
        }


        public function getorderdata($table) {
            $query = "SELECT * from $table";
            $result = mysqli_query($this->link, $query);
            $res = []; 
            if (mysqli_num_rows($result) > 0) {
                $res = mysqli_fetch_all($result, MYSQLI_ASSOC);
            }
            return $res;
        }



        public function getViewOrder( $table, $proid) {
            $query = "SELECT cart.pname, cart.pimage, cart.qty,cart.prize
            FROM orderdetails 
            LEFT JOIN $table ON orderdetails.userid = $proid 
            ORDER BY cart.pname;
            ";
            $result = mysqli_query($this->link, $query);
            $res = []; 
            if ($result && mysqli_num_rows($result) > 0) {
                $res = mysqli_fetch_all($result, MYSQLI_ASSOC);
            }
            return $res;
        }
        
        
        public function addToCart() {
            
            extract($_REQUEST);
            
        
            $query = "INSERT INTO cart (id, pname, pimage, prize, size1, qty, userid) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($this->link, $query);
            
          
            mysqli_stmt_bind_param($stmt, "isssssi", $proid, $pname, $image, $prize, $size, $add, $user);
           
            $result = mysqli_stmt_execute($stmt);
            
            
            if ($result) {
                header('location:../view/user/checkpoint');
            } else {
                echo mysqli_error($this->link);
            }
            
           
            mysqli_stmt_close($stmt);
        }
        


        public function addProduct() {
          
            extract($_REQUEST);
            
            if ($_FILES["pic"]["error"] > 0) {
                echo "Error: " . $_FILES["pic"]["error"];
            } else {
                $filename = substr($_FILES["pic"]["name"], 0, 255);
            
               
                $query = "INSERT INTO admins (pname, pimage, decription, prize, categryid) VALUES (?, ?, ?, ?, ?)";
                $stmt = mysqli_prepare($this->link, $query);
                
                
                mysqli_stmt_bind_param($stmt, "ssssi", $name, $filename, $detail, $prize, $category);
                
               
                $result = mysqli_stmt_execute($stmt);
                
               
                if ($result) {
                    header('location:../view/admin/adminindex');
                } else {
                    echo mysqli_error($this->link);
                }
                
               
                mysqli_stmt_close($stmt);
            }
        }
        


        public function updateProduct() {
            
            extract($_REQUEST);
            
            if ($_FILES["pic"]["error"] > 0) {
                echo "Error: " . $_FILES["pic"]["error"];
            } else {
                $filename = substr($_FILES["pic"]["name"], 0, 255);
            
               
                $query = "UPDATE admins SET pname=?, pimage=?, decription=?, prize=?, categryid=? WHERE id=?";
                $stmt = mysqli_prepare($this->link, $query);
                
              
                mysqli_stmt_bind_param($stmt, "ssssii", $pname, $filename, $Description, $prize, $Category, $id);
                
              
                $result = mysqli_stmt_execute($stmt);
                
              
                if ($result) {
                    header('location:../view/admin/adminindex');
                } else {
                    echo mysqli_error($this->link);
                }
                
               
                mysqli_stmt_close($stmt);
            }
        }
        

        public function getParticularProduct( $table, $proid) {
            $query = "SELECT * from $table where id=$proid";
            $result = mysqli_query($this->link, $query);
            $res = [];
            if (mysqli_num_rows($result) > 0) {
                $res = mysqli_fetch_all($result, MYSQLI_ASSOC);
            }
            return $res;
        }


        public function getCartItems( $table, $proid) {
            $query = "SELECT * from $table where userid=$proid";
            $result = mysqli_query($this->link, $query);
            $res = [];
            if ($result === false) {
             
            } else {
               
                $num_rows = mysqli_num_rows($result);
                $res = mysqli_fetch_all( $result, MYSQLI_ASSOC);
            }
            return $res;
        }
        
        

        public function getAlldata($table) {
            $query = "SELECT * from $table";
            $result = mysqli_query($this->link, $query);
            $res = []; 
            if (mysqli_num_rows($result) > 0) {
                $res = mysqli_fetch_all($result, MYSQLI_ASSOC);
            }
            return $res;
        }


        public function getalldatas($table) {
            $query = "SELECT * from $table";
            $result = mysqli_query($this->link, $query);
            $res = []; 
            if (mysqli_num_rows($result) > 0) {
                $res = mysqli_fetch_all($result, MYSQLI_ASSOC);
            }
            return $res;
        }
    
      
        public  function getPaticulaproduct($table, $usid) {
            $query = "SELECT * from $table where id=$usid";
            $result = mysqli_query($this->link, $query);
            $res = [];
            if (mysqli_num_rows($result) > 0) {
                $res = mysqli_fetch_all($result, MYSQLI_ASSOC);
            }
            return $res;
        }

        public function resetPassword() {
          
            
           
            extract($_REQUEST);
            
          
            $query = "SELECT * FROM userdata WHERE username=?";
            $stmt = mysqli_prepare($this->link, $query);
            
          
            mysqli_stmt_bind_param($stmt, "s", $email);
            
           
            $result = mysqli_stmt_execute($stmt);
            
            if ($result) {
              
                $result = mysqli_stmt_get_result($stmt);
                $num_rows = mysqli_num_rows($result);
                
                if ($num_rows > 0) {
                
                    header('location:../view/user/forget');
                } else {
                   
                    header('location:../view/user/register');
                }
            } else {
                echo mysqli_error($this->link);
            }
            
           
            mysqli_stmt_close($stmt);
        }
        

            public  function  forgotPassword() {
                extract($_REQUEST);
                $pass = $_REQUEST['password1'];
                $hashpassword = md5($pass);
                    $query = "UPDATE userdata set setPass='$hashpassword' where username='$email'";
                    $result = mysqli_query($this->link, $query);
                    if ($result) {
                      
                        header('location:../view/user/register');
                    
                    } else {
                        echo mysqli_error($link);
                    }
                } 



                public  function deleteItem() {
                    extract($_REQUEST);
                    $dquery = "delete from cart where id=$userid";
                    $result = mysqli_query($this->link, $dquery);
                    if ($result) {
                        header('location:../view/user/checkpoint');
                    }
                }


                public    function deleteProduct() {
                    extract($_REQUEST);
                    $dquery = "delete from admins where id=$prpid";
                    $result = mysqli_query($this->link, $dquery);
                    if ($result) {
                        header('location:../view/admin/adminindex');
                    }
                }


                public function fetchUserData(){
                    extract($_REQUEST);
                    
                        $query = "INSERT INTO orderdetails (fullname, email, phone, addressuser, city, states, zip, country, cardnumber, expiry, cvv,userid) VALUES (?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?,?)";
                        $stmt = mysqli_prepare($this->link, $query);
                        mysqli_stmt_bind_param($stmt,"sssssssssssi", $fullname, $email, $phone, $address, $city, $state, $zip, $country, $cardnumber, $expiry, $cvv, $userid);
                        $result=mysqli_stmt_execute($stmt);
                        if ($result) {
                            
                            header("Location: ../view/user/orderdetails");
                        } else {
                            
                            header("Location: ../view/user/orderdetails");
                        
                    } 
                    mysqli_stmt_close($stmt);

}




}






?>

