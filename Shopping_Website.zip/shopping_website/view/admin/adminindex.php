






<?php 
extract($_REQUEST);
include '../../controler/adminController.php';


if (!isset($_SESSION['useremail']) || $_SESSION['useremail'] == "") {
    header('location:index');
    exit; 
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Product Management</title>
    <style>
        /* Reset default margin and padding */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Style the navigation menu */
        .navbar {
            list-style-type: none;
            padding: 0;
            background-color: #f1f1f1;
        }

        /* Style the links inside the navigation menu */
        .navbar li {
            text-align: center;
            padding: 10px;
        }

        /* Change color on hover */
        .navbar li:hover {
            background-color: #ddd;
        }

        /* Style the active/current link */
        .active {
            background-color: #4CAF50;
            color: white;
        }

        /* Main Content */
        .container {
            display: flex;
            flex-wrap: wrap;
        }

        /* Form Container */
        .main {
            flex: 1;
            padding: 20px;
        }

        /* Responsive Navigation */
        @media screen and (max-width: 600px) {
            .navbar {
                width: 100%;
            }
            .navbar li {
                width: 50%;
            }
        }

        /* Style for the collections */
        .mencollection,
        .womencollection {
            width: 48%;
            margin-bottom: 20px;
            float: left;
        }

        /* Responsive Collection Layout */
        @media screen and (max-width: 600px) {
            .mencollection,
            .womencollection {
                width: 100%;
            }
        }

        /* Style for tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            border:1px solid black;
            border-collapse:collapse;
        }

        table th,
        table td {
            padding: 10px;
            text-align: left;
            
        }
        td{
border-bottom:1px solid white;
            background-color:#D6DBDF ; 

        }

        /* Style for alternating row colors */
        
        /* Style for collection titles */
        h2 {
            margin-top: 0;
            margin-bottom: 10px;
        }
        body{
background-color:#EBDEF0 ; 


}


#show1{

display:none;

}
#show3{

display:none;

}
#show4{

display:none;

}
.main{

    background-color:#F4ECF7;
    border-top-right-radius: 25px;
border-bottom-right-radius: 25px;
border-top-left-radius: 25px;
 border-bottom-left-radius: 25px;
}

    </style>

   
</head>
<body>


    <div class="container">
    <script>
function show(){

    
    document.getElementById("show1").style.display = "block";
    document.getElementById("show3").style.display = "none";
    document.getElementById("show2").style.display="none";
    document.getElementById("show4").style.display = "none";
}
function show1(){

    
document.getElementById("show2").style.display="flex";
document.getElementById("show1").style.display="none";
document.getElementById("show3").style.display = "none";
document.getElementById("show4").style.display = "none";
}
function show3(){

    
document.getElementById("show2").style.display="none";
document.getElementById("show1").style.display="none";
document.getElementById("show3").style.display = "block";
document.getElementById("show4").style.display = "none";
}
function show4(){

    
document.getElementById("show2").style.display="none";
document.getElementById("show1").style.display="none";
document.getElementById("show3").style.display = "none";
document.getElementById("show4").style.display = "block";
}


        </script>
        <div class="">

<!-- Vertical Navigation Menu -->
<ul class="navbar">
    <li><a href="#" onclick="show()">Product Add</a></li>
    <li><a href="#"onclick="show3()">Customer Details</a></li>
    <li><a href="#"onclick="show1()">Product View</a></li>
    <li><a href="#"onclick="show4()">Order Details</a></li>
    <li><a href="logout">logout</a></li>
</ul>
</div>
<!-- Main Content -->
<div class="main">
    <div id="show1">
        <form method="post" action="../../controler/userResponce.php" enctype="multipart/form-data">
            <table>
                <tr>
                    
                    <td>Product Image<input type="file" id="pic" name="pic"></td>
                </tr>
                <tr>
                    
                    <td>Product Name<input type="text" id="name" name="name"></td>
                </tr>
                <tr>
                   
                    <td>Product Description<input type="text" id="detail" name="detail"></td>
                </tr>
                <tr>
                    
                    <td>Product Price<input type="text" id="prize" name="prize"></td>
                </tr>
                <tr>
                   
                    <td>Category ID<input type="text" id="category" name="category"></td>
                </tr>
                <tr>
                    <td><input type="submit" id="submit" name="submit" value="store"></td>
                </tr>
            </table>
        </form>
    </div>
    <div id="show2">
    <div class="mencollection">
        <?php
       
        if (!empty($productdata)) {
            ?>
            <h2>Men Collection</h2>
            <table>
                <tr>
                    <th>Product Image</th>
                    <th>Product Name</th>
                    <th>Product Description</th>
                    <th>Product Price</th>
                    <th>Category ID</th>
                    <th>Actions</th>
                </tr>
                <?php
                
                foreach ($productdata as $row) {
                    
                    if ($row['categryid'] == 1) {
                        ?>
                        <tr>
                            <td><img src="../image/<?= $row['pimage'] ?>" alt="../image/<?= $row['pimage'] ?>" width="100%" height="60px"></td>
                            <td><?= $row['pname'] ?></td>
                            <td><?= $row['decription'] ?></td>
                            <td><?= $row['prize'] ?></td>
                            <td><?= $row['categryid'] ?></td>
                            <td>
                                        <a href="edit?usid=<?= $row['id'] ?>"><button style="background-color:#AED6F1 ;border:none;padding:5px;">Edit</button></a>  
                                      
                            
                                    <a href="../../controler/userResponce.php?prpid=<?= $row['id'] ?>&submit=deleteproduct" ><button><i class="fa-solid fa-trash" style="color: #ed1219;"></i></button></a>
                    </td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </table>
            <?php
        } else {
            // If no records are found, display a message
            echo 'Record Not found';
        }
        ?>
    </div>

    <div class="womencollection">
        <?php
        // Check if any records are found
        if (!empty($productdata)) {
            ?>
            <h2>Women Collection</h2>
            <table>
                <tr>
                    <th>Product Image</th>
                    <th>Product Name</th>
                    <th>Product Description</th>
                    <th>Product Price</th>
                    <th>Category ID</th>
                    <th>Actions</th>
                </tr>
                <?php
                // Loop through each row of data
                foreach ($productdata as $row) {
                    // Check if the category ID is 2
                    if ($row['categryid'] == 2) {
                        ?>
                        <tr>
                            <td><img src="../image/<?= $row['pimage'] ?>" alt="../image/<?= $row['pimage'] ?>" width="100%" height="60px"></td>
                            <td><?= $row['pname'] ?></td>
                            <td><?= $row['decription'] ?></td>
                            <td><?= $row['prize'] ?></td>
                            <td><?= $row['categryid'] ?></td>
                            <td>
                                        <a href="edit?usid=<?= $row['id'] ?>"><button style="background-color:#AED6F1 ;border:none;padding:5px;">Edit</button></a>  
                                       <br>
                            
                                       <a href="../../controler/userResponce.php?prpid=<?= $row['id'] ?>&submit=deleteproduct" ><button><i class="fa-solid fa-trash" style="color: #ed1219;"></i></button></a>

                    </td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </table>
            <?php
        } else {
            // If no records are found, display a message
            echo 'Record Not found';
        }
        ?>
    </div>
</div>
<div id="show3">
<div class="userdetails">
<?php
        // Fetch data from the database
        
        
        // Check if any records are found
        if (!empty($userdata)) {
            ?>
            <h2>user data</h2>
            <table>
                <tr>
                  
                    <th>FirstName</th>
                    <th>LastName</th>
                    <th>Email</th>
                    <th>Password</th>
                </tr>
                <?php
                // Loop through each row of data
                foreach ($userdata as $row) {
                    // Check if the category ID is 1
                    if ($row) {
                        ?>
                        <tr>
                            <td><?= $row['fname'] ?></td>
                            <td><?= $row['lname'] ?></td>
                            <td><?= $row['username'] ?></td>
                            <td><?= $row['setPass'] ?></td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </table>
            <?php
        } else {
            // If no records are found, display a message
            echo 'Record Not found';
        }
        ?>
    </div>
    </div>
    <div id="show4">
<div class="orderdetails">
<?php
        // Fetch data from the database
       
        
        // Check if any records are found
        if (!empty($orderdata)) {
            ?>
            <h2>order data</h2>
            <table>
            <tr>
        <th>Full Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Address</th>
        <th>City</th>
        <th>State/Province</th>
        <th>ZIP/Postal Code</th>
        <th>Country</th>
        <th>Credit Card Number</th>
        <th>Expiration Date</th>
        <th>CVV/CVC</th>
        <th>User ID</th>
    </tr>
                <?php
                // Loop through each row of data
                foreach ($orderdata as $row) {
                    // Check if the category ID is 1
                    if ($row) {
                        ?>
                        <tr>
                    
                            <td><?= $row['fullname'] ?></td>
                            <td><?= $row['email'] ?></td>
                            <td><?= $row['phone'] ?></td>
                            <td><?= $row['addressuser'] ?></td>
                            <td><?= $row['city'] ?></td>
                            <td><?= $row['states'] ?></td>
                            <td><?= $row['zip'] ?></td>
                            <td><?= $row['country'] ?></td>
                            <td><?= $row['cardnumber'] ?></td>
                            <td><?= $row['expiry'] ?></td>
                            <td><?= $row['cvv'] ?></td>
                            <td><?= $row['userid'] ?></td>
                            
                        </tr>
                        <?php
                    }
                }
                ?>
            </table>
            <?php
        } else {
            // If no records are found, display a message
            echo 'Record Not found';
        }
        ?>
    </div>
    </div>
</div>
</body>
</html>










