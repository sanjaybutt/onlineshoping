<?php

session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="style6.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-25">
                <img src="../image/img.png" style="width:100%;">
            </div>
            <div class="col-50">
                <div class="right">
                    <h1>ADMIN Login Page</h1>
                    <form id="form1" name="form1" method="post">
    <div class="col-1">
        <label for="user">Email</label><br>
        <input type="email" id="username" name="username"><br>
        <span id="usererr" style="color: #e6130c; font-size:15px;"></span>
    </div>
    <div class="col-1">
        <label for="password">Password</label><br>
        <input type="password" id="password" name="password"><br>
        <span id="passerr" style="color: #e6130c; font-size:15px;"></span><br>
    </div>
    <div class="col-1">
        <input type="submit" id="submit" name="submit" value="Login">
    </div>
</form>
</div>
</div>  
</div>
</div>
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['username'];
    $password = $_POST['password'];

    if ($name === "admin@gmail.com" && $password === "12345678") {
        $_SESSION['useremail'] = $name;
        header('location:adminindex');
        exit; 
    } else {
        header('location:index');
        exit; 
    }
}
?>

</body>
</html>
