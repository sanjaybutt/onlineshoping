

<?php
// Start the session
session_start();

// Unset all of the session variables
$_SESSION = array();

// Destroy the session
unset($_SESSION['useremail']);
// Redirect to the login page
header("Location: index");
exit;
?>
