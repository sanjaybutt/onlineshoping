<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>
<?php

extract($_REQUEST);
include '../../controler/adminController.php';
?>
<!doctype html>
<html>
    <head>
        <title>Employee list</title>
       
    </head>
    <body>
        <div class="container">
            <div class="left">
            </div>
            <div class="right">
                <?php
              
                if(!empty($particulardata)){
                    ?>
                <form class="form" id="updateform" method="post" action="../../controler/userResponce.php" enctype="multipart/form-data">
                        <table cellspacing="20">
                            <tr>
                                <th colspan="2"><center>Product Upade</center> <span id="update-status"></span></th>
                            </tr>
                            <?php
                            
                           foreach($particulardata as $row) {
                                ?>
 
                                <tr>
                                    <td>Product ID</td>
                                    <td><input type="text" name="id" id="pid"  value="<?= $row['id'] ?>" readonly="" /></td>
                                </tr>

                                <tr>
                                    <td>Category ID</td>
                                    <td><input type="text" name="Category" id="Category"  value="<?= $row['categryid'] ?>" /></td>
                                </tr>
                                <tr>
                                    <td>Name</td>
                                    <td><input type="text" name="pname" id="pname" value="<?= $row['pname'] ?>"/></td>
                                </tr>
                                <tr>
                                    <td>Prize</td>
                                    <td><input type="text" name="prize" id="prize"  value="<?= $row['prize'] ?>"/></td>
                                </tr>
                                <tr>
                                    <td>Description</td>
                                    <td><input type="text" name="Description" id="Description"  value="<?= $row['decription'] ?>"/></td>
                                </tr>
                                <tr>
                                    <td>Photo</td>
                                    <td><img src="../image/<?= $row['pimage'] ?>" alt=" Picture" width="200" height="200"/></td>
                                </tr>
                                <tr>
                                    <td>Change(optional)</td>
                                    <td><input type="file" name="pic" id="pic" /></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td><button class="btn" name="submit" id="submit" value="update">Update</button></td>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </form>
                    <?php
                } else {
                    echo 'Record Not found';
                }
                ?>
            </div>
        </div> 
    </body>
</html>