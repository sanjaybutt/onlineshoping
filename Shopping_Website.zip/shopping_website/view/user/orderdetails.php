<?php 

include '../../model/dbquery.php';
extract($_REQUEST);

if (!isset($_SESSION['userid']) || $_SESSION['userid'] == "") {
    header('location: register');
    exit; 
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
<title>sara</title>
 
  <style>
   
body{
background-color:#EBDEF0 ; 


}
.container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color:#F4ECF7  ;
  border-radius: 5px;
  border-top-right-radius: 25px;
border-bottom-left-radius: 25px;
}

h2 {
  text-align: center;
}

form {
  display: grid;
  grid-gap: 10px;
}

label {
  font-weight: bold;
  margin-left:15%;
}

input[type="text"],
input[type="email"],
input[type="tel"] {
  width: 70%;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 3px;
  margin-left:15%;
}

input[type="text"]:focus,
input[type="email"]:focus,
input[type="tel"]:focus {
  outline: none;
  border-color: #007bff;
}

button[type="submit"] {
  margin-left:40%;
  width: 20%;
  padding: 10px;
  background-color: #AED6F1;
  color: #fff;
  border: none;
  border-radius: 3px;
  cursor: pointer;
  transition: background-color 0.3s ease; 
}

button[type="submit"]:hover {
  animation: pulse 0.5s infinite alternate; 
}

@keyframes pulse {
  from {
    background-color: #007bff;
  }
  to {
    background-color: #0056b3;
  }
}

    </style>
</head>
<body>



<script>
  function validateForm() {
    // Get input field values
    var fullname = document.getElementById('fullname').value;
    var email = document.getElementById('email').value;
    var phone = document.getElementById('phone').value;
    var address = document.getElementById('address').value;
    var city = document.getElementById('city').value;
    var state = document.getElementById('state').value;
    var zip = document.getElementById('zip').value;
    var country = document.getElementById('country').value;
    var cardnumber = document.getElementById('cardnumber').value;
    var expiry = document.getElementById('expiry').value;
    var cvv = document.getElementById('cvv').value;

    // Simple validation - check if fields are not empty
    if (fullname === "" || email === "" || phone === "" || address === "" || city === "" || state === "" || zip === "" || country === "" || cardnumber === "" || expiry === "" || cvv === "") {
      
      toastr.error('All fields must be filled out', 'Error');
      return false;
    }

    // Validation for email format
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.match(emailRegex)) {
   
      toastr.error('Invalid email format', 'Error');
      return false;
    }

    // Validation for phone number format
    var phoneRegex = /^\d{10}$/;
    if (!phone.match(phoneRegex)) {

      toastr.error('Invalid phone number format. Please enter 10 digits only.t', 'Error');
      return false;
    }
    var creditCardRegex = /^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|6(?:011|5[0-9]{2})[0-9]{12}|(?:2131|1800|35\d{3})\d{11})$/;
    
    if (!cardnumber.match(creditCardRegex)) {
      toastr.error('Please enter a valid credit card number.', 'Error');
        return false;
    }
    var expiryDateRegex = /^(0[1-9]|1[0-2])\/[0-9]{2}$/;
    
    if (!expiry.match(expiryDateRegex)) {
      toastr.error('Please enter a valid expiration date in the format MM/YY', 'Error');
        return false;
    }
    var cvvRegex = /^\d{3,4}$/;
    
    if (!cvv.match(cvvRegex)) {
      toastr.error('Please enter a valid CVV consisting of 3 or 4 digits', 'Error');
        return false;
    }

    toastr.success('Order Successful', 'Success');
    return true;
  }
</script>


  <div class="container">
    <h2>Payment Details</h2>
    <form action="../../controler/userResponce.php" method="POST" onsubmit="return validateForm()"> 
      <label for="fullname">Full Name</label>
      <input type="text" id="fullname" name="fullname" >

      <label for="email">Email Address</label>
      <input type="email" id="email" name="email">

      <label for="phone">Phone Number</label>
      <input type="tel" id="phone" name="phone" >

      <label for="address">Billing Address</label>
      <input type="text" id="address" name="address" >

      <label for="city">City</label>
      <input type="text" id="city" name="city" >

      <label for="state">State/Province</label>
      <input type="text" id="state" name="state" >

      <label for="zip">ZIP/Postal Code</label>
      <input type="text" id="zip" name="zip" >

      <label for="country">Country</label>
      <input type="text" id="country" name="country" >

      <label for="cardnumber">Credit Card Number</label>
      <input type="text" id="cardnumber" name="cardnumber" >

      <label for="expiry">Expiration Date</label>
      <input type="text" id="expiry" name="expiry" placeholder="MM/YYYY" >

      <label for="cvv">CVV/CVC</label>
      <input type="text" id="cvv" name="cvv" >
      <input type="hidden" id="userid" name="userid" value="<?php echo"$name"?>">

      <button type="submit"name="submit" value="userdata">Submit Payment</button>
    </form>
  </div>
  <div class="col-1">
          <i class="fa-solid fa-backward fa-flip-vertical fa-xs" style="color: #74C0FC;"></i><a href="index1"><button>Back to page</button></a>
        </div>
</body>
</html>
