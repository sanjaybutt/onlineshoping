<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sara</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div id="forget">
        <div class="row">
    <div class="col-25">
    

    
    
    </div>
    <div class="col-50">
        <div class="right">
            <h1>
                <br>
                forgot Page
              </h1>
          
            <form id ="form1"  method="post" action="../../controler/userResponce.php">
                <div class="col-1">
           <label for="email">email</label><br>
           <input type="email" id="email" name="email" ><br>
           
    </div>
    <div class="col-1">
        <label for="pas2"> confirm Password</label><br>
        <input type="password" id="password1" name="password1" ><br>
       
    </div>
    <div class="col-1">
       
        <input type="submit" id="submit" name="submit" value="forgotpassword"><br>
    <h5>or</h5>
    </div>
    <div class="col-1">
          <i class="fa-solid fa-backward fa-flip-vertical fa-xs" style="color: #74C0FC;"></i>    <a href="register">Back to login</a>
        </div>
            </form>
        </div>
    
    </div>
    </div>  
</div>
</div>


</body>
</html>