
<?php session_start() ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sara</title>
    <link rel="stylesheet" href="../css/style2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
   <div class="container">
<header>
<h2>Sɑɾɑ ƒɑSҺıᴏꞃ</h2>
<ul div class="navi">
<li> <div class="username"><h3 style="color:white;"><?php echo"$user"  ?></h3></div></li>
<li><a href="checkpoint"><i class="fa-solid fa-bag-shopping fa-lg" style="color: #121212;"></i></a></li>
<li><a href="register"><i class="fa-solid fa-user" style="color: #0a0a0a;"></i></a></li>
<li><a href="logout">logout</a></li>

</ul>
</div>


</header>
<navi>

<ul  class="nav">
<li><a href="men">𝖬𝖾𝗇</a></li>
<li><a href="women">𝖶𝗈𝗆𝖾𝗇</a></li>
</ul>

</navi>







</div>
</body>
</html>
