
<?php
extract($_REQUEST);
include '../../controler/userController.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sara</title>
    <style>
        
.card{

 background-color:#EBDEF0 ; 
height:800px;
margin-left:250px;
width:60%;
border-top-right-radius: 25px;
border-bottom-left-radius: 25px;
}
.left{


float:left;
width:20%;
margin-left:100px;


}
.main{
   padding-left:20px;
    float:left;
  background-color:#F8F9F9 ;
    width:50%;
     margin-left:20px;
     height:300px;
     border-top-left-radius: 25px;
border-bottom-right-radius: 25px;
}
input[type="number"]{

    width:20%;
border:none;
border-bottom:1px solid black;
}
    img:hover {
  -webkit-transform: scaleX(-1);
  transform: scaleX(-1);
}




.right{

    float:left;
  background-color:#F8F9F9 ;
    width:30%;
    margin-left:20px;
    margin-top:10px;
     height:300px;
     border-top-left-radius: 25px;
border-bottom-right-radius: 25px;

}

.right1{

float:left;
background-color:#F8F9F9 ;
width:30%;
margin-left:20px;
margin-top:10px;
 height:300px;
 border-top-right-radius: 25px;
border-bottom-left-radius: 25px;

}


        </style>
</head>
<body>
    
<div class="container">




<?php
                
              
      
              
                if(!empty($products)){
                    ?>
                
                       
                            <?php
                            
                           foreach($products as $row) {
                                ?>
                                <form action="../../controler/userResponce.php" method="post">
                                <div  class="card">
                                <h2  style="margin-left:100px;"> <?= $row['pname'] ?></h2>
                                    <div class="left">
                     <img src="../image/<?= $row['pimage'] ?>" alt="Profile Picture" width="100%"/>
                     <br>
                    <div class="img">
                        <table>
                            <tr>
                    <td> <img src="../image/<?= $row['pimage'] ?>" alt="Profile Picture" width="100%"/> </td>
                      <td><img src="../image/<?= $row['pimage'] ?>" alt="Profile Picture" width="100%"/></td>
                      <td><img src="../image/<?= $row['pimage'] ?>" alt="Profile Picture" width="100%"/></td>
                           </tr>
                           </table>
                           </div>
                           </div>
                              <div class="main">
                              <h3>RS:<?= $row['prize'] ?></h3>
                              <input type="hidden" value="<?= $row['prize'] ?>" name="prize">
                              <input type="radio" value="S" name="size">S
                              <input type="radio" value="M"name="size">M
                              <input type="radio" value="L" name="size">L
                                <input type="hidden" value="image/<?= $row['pimage'] ?>" name="image">
                                <input type="hidden" value="<?= $row['pname'] ?>" name="pname">
                                <input type="hidden" value="<?php echo"$name"    ?>" name="user">
                                <input type="hidden" value=" <?= $row['id'] ?>" name="proid">
                              <p style="text-align:justify;padding-right:10px;"><?= $row['decription'] ?></p>
                               <input type="number" id="add" name="add"><br> <br>
                               <button type="submit" name="submit" value="add">chekout</button>
                           </div>
                           <div class="right"style="padding-left:10px;">
                                      <h5>RETURN</h5>
                                   <p style="text-align:justify;padding:0 5px 5px 5px;">𝐸𝑎𝑠𝑦 10 𝑑𝑎𝑦𝑠 𝑟𝑒𝑡𝑢𝑟𝑛 𝑎𝑛𝑑 𝑒𝑥𝑐ℎ𝑎𝑛𝑔𝑒. 𝑅𝑒𝑡𝑢𝑟𝑛 𝑃𝑜𝑙𝑖𝑐𝑖𝑒𝑠 𝑚𝑎𝑦 𝑣𝑎𝑟𝑦 𝑏𝑎𝑠𝑒𝑑 𝑜𝑛 𝑝𝑟𝑜𝑑𝑢𝑐𝑡𝑠 𝑎𝑛𝑑 𝑝𝑟𝑜𝑚𝑜𝑡𝑖𝑜𝑛𝑠. 𝐹𝑜𝑟 𝑓𝑢𝑙𝑙 𝑑𝑒𝑡𝑎𝑖𝑙𝑠 𝑜𝑛 𝑜𝑢𝑟 𝑅𝑒𝑡𝑢𝑟𝑛𝑠 𝑃𝑜𝑙𝑖𝑐𝑖𝑒𝑠, 𝑝𝑙𝑒𝑎𝑠𝑒 𝑐𝑙𝑖𝑐𝑘 ℎ𝑒𝑟𝑒․</p>


                           </div>
                           <div class="right1"style="padding-left:10px;">
                                      <h5>𝙾𝙵𝙵𝙴𝚁𝚂 <button style="color:white;background-color:#85C1E9;border:none;">21 Offers Available</button></h5>
                                   <p style="text-align:justify;padding:0 5px 5px 5px;">𝐃𝐫𝐞𝐬𝐬𝐞𝐬 𝐂𝐨𝐮𝐩𝐨𝐧𝐬 𝐀𝐧𝐝 𝐃𝐢𝐬𝐜𝐨𝐮𝐧𝐭 𝐂𝐨𝐝𝐞𝐬 𝐅𝐨𝐫 𝐌𝐚𝐲 𝟐𝟎𝟐𝟒</p>
                                   <p style="text-align:justify;padding:0 5px 5px 5px;">𝑫𝒓𝒆𝒔𝒔𝒆𝒔 – 𝑴𝒊𝒏 30% 𝑶𝒇𝒇 + 𝑬𝒙𝒕𝒓𝒂 𝑹𝒔.200 𝑵𝒆𝒘 𝑼𝒔𝒆𝒓 𝑶𝒇𝒇 + 𝑰𝒏𝒔𝒕𝒂𝒏𝒕 10% 𝑩𝒂𝒏𝒌 𝑶𝒇𝒇 𝑶𝒏 𝑺𝒕𝒚𝒍𝒊𝒔𝒉 & 𝑻𝒓𝒆𝒏𝒅𝒚 𝑫𝒓𝒆𝒔𝒔𝒆𝒔</p>

                                   <p style="text-align:justify;padding:0 5px 5px 5px;">𝑫𝒓𝒆𝒔𝒔𝒆𝒔 – 𝑼𝒑𝒕𝒐 40% 𝑶𝒇𝒇 + 𝑬𝒙𝒕𝒓𝒂 15% 𝑶𝒇𝒇 𝑶𝒏 𝑫𝒓𝒆𝒔𝒔 & 𝑱𝒖𝒎𝒑𝒔𝒖𝒊𝒕𝒔 (𝑴𝒊𝒏 𝑶𝒓𝒅𝒆𝒓 𝑶𝒇 𝑹𝒔.2500 & 𝑨𝒃𝒐𝒗𝒆)</p>

                           </div>
                           </div>
                           </form>
                                <?php
                            }
                            ?>
        
                    <?php
                } else {
                    echo 'Record Not found';
                }
                ?>












</div>
</body>
</html>