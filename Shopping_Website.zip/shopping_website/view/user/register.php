<?php
include '../controler/userResponce.php';


?>


<html>
<head>
<title>Register Page</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="../css/style.css">


</head>
<body>

    <script>



function myFunction1(){
    document.getElementById("register").style.display = "none";
    document.getElementById("forgot").style.display = "none";
    document.getElementById("login").style.display = "block";
   

}
function myFunction2(){
    document.getElementById("register").style.display = "block";
    document.getElementById("forgot").style.display = "none";
    document.getElementById("login").style.display = "none";
}

function myFunction3(){
    document.getElementById("register").style.display = "none";
    document.getElementById("forgot").style.display = "none";
    document.getElementById("login").style.display = "block";
}
function myFunction4(){
    document.getElementById("register").style.display = "none";
    document.getElementById("forgot").style.display = "block";
    document.getElementById("login").style.display = "none";
}





    </script>
<div class="container">
    <div id="register">
<div class="row">
<div class="col-25">

<img src="../image/register-removebg-preview.png">


</div>
<script>
function validateForm() {
    var firstname = document.getElementById("firstname").value;
    var lastname = document.getElementById("lastname").value;
    var email = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    var nameErr = document.getElementById("nameerr");
    var lastnameErr = document.getElementById("lastnameerr");
    var emailErr = document.getElementById("usernameerr");
    var passwordErr = document.getElementById("passworderr");

    nameErr.innerHTML = "";
    lastnameErr.innerHTML = "";
    emailErr.innerHTML = "";
    passwordErr.innerHTML = "";

    var isValid = true;

    if (firstname == "") {
        nameErr.innerHTML = "First name is required";
        isValid = false;
    }

    if (lastname == "") {
        lastnameErr.innerHTML = "Last name is required";
        isValid = false;
    }

    if (email == "") {
        emailErr.innerHTML = "Email is required";
        isValid = false;
    } else {
        // Simple email validation
        var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            emailErr.innerHTML = "Invalid email address";
            isValid = false;
        }
    }

    if (password == "") {
        passwordErr.innerHTML = "Password is required";
        isValid = false;
    }

    return isValid;
}
</script>

<div class="col-50">

    <div class="right">
      <h1>
        <br>
        Register Page
      </h1>

      <form method="post" action="../../controler/userResponce.php" onsubmit="return validateForm()">
    <div class="col-1">
        <label for="user1">First Name</label><br>
        <input type="text" id="firstname" name="firstname" value="<?php echo isset($_POST['firstname']) ? $_POST['firstname'] : ''; ?>"><br>
        <span id="nameerr" style="color: #e6130c; font-size:15px;"><?php echo isset($firstnameErr) ? $firstnameErr : ''; ?></span>
    </div>
    <div class="col-1">
        <label for="user2">Last Name</label><br>
        <input type="text" id="lastname" name="lastname" value="<?php echo isset($_POST['lastname']) ? $_POST['lastname'] : ''; ?>"><br>
        <span id="lastnameerr" style="color: #e6130c; font-size:15px;"><?php echo isset($lastnameErr) ? $lastnameErr : ''; ?></span>
    </div>
    <div class="col-1">
        <label for="user">Email</label><br>
        <input type="email" id="username" name="username" value="<?php echo isset($_POST['username']) ? $_POST['username'] : ''; ?>"><br>
        <span id="usernameerr" style="color: #e6130c; font-size:15px;"><?php echo isset($usernameErr) ? $usernameErr : ''; ?></span>
    </div>
    <div class="col-1">
        <label for="password">Password</label><br>
        <input type="password" id="password" name="password"><br>
        <span id="passworderr" style="color: #e6130c; font-size:15px;"><?php echo isset($passwordErr) ? $passwordErr : ''; ?></span>
    </div>
    <div class="col-1">
        <input type="submit" id="submit1" name="submit" value="create"><br>
        <h5>or</h5>
    </div>
    <div class="col-1">
        <h3>Already have an account? <a href="#login" onclick="myFunction1()">Sign in</a></h3>
    </div>
</form>

        
        <script>



            document.getElementById("firstname").addEventListener("keyup", myFunction);
            document.getElementById("lastname").addEventListener("keyup", myFunction);
            document.getElementById("username").addEventListener("keyup", myFunction);
            document.getElementById("password").addEventListener("keyup", myFunction);
         
         function myFunction() {
           let firstname = document.getElementById("firstname").value;
           let lastname= document.getElementById("lastname").value;
           let username = document.getElementById("username").value;
           let password= document.getElementById("password").value;

           


           if((firstname=="")){
         
             document.getElementById("nameerr").innerHTML=  
         " Please enter firstname ";  
         status=false;  
         }else{  
         document.getElementById("nameerr").innerHTML="";  
         status=true;  
         }  

         if((lastname=="")){
         
         document.getElementById("lastnameerr").innerHTML=  
     " Please enter lastname ";  
     status=false;  
     }else{  
     document.getElementById("lastnameerr").innerHTML="";  
     status=true;  
     } 
     if((username=="")){
         
         document.getElementById("usernameerr").innerHTML=  
     " plz enter username  ";  
     status=false;
     } 
     else if((username.length<5)){
         
         document.getElementById("usernameerr").innerHTML=  
     " atleast five character  ";  
     status=false;  
     }
     else{  
     document.getElementById("usernameerr").innerHTML="";  
     status=true;  
     }  
     if((password=="")){
         
         document.getElementById("passworderr").innerHTML=  
     " plz enter password  ";  
     status=false;
     } 
     else if((password.length<8)){
         
         document.getElementById("passworderr").innerHTML=  
     "  Password is week ";  
     status=false;  
     }
     else{


        document.getElementById("passworderr").innerHTML=" <i style='color: #5ec44a;'>strong password</i>";  
     status=true;  


     }
      
     
         
         
         
           }
         
            
         
         
          
         
         
         
         
         
         
         
         
         
         
         
         
             </script>
    </div>
</div>
</div>
</div>
<!-- login page-->
<div id="login">
<div class="row">
    <div class="col-25">
    
    <img src="../image/img.png">
    
    
    </div>
    <div class="col-50">
        <div class="right">
            <h1>
                <br>
                Login Page
              </h1>
             
              <?php
   
   if (isset($_GET)) {
   $passworderror = htmlspecialchars(urldecode($_GET['error'])) ;
   $nameerror = htmlspecialchars(urldecode($_GET['error1'])) ;
   $invaliderror = htmlspecialchars(urldecode($_GET['error2'])) ;
}
?>
 
              <form id="form1" method="post" action="../../controler/userResponce.php">
            
    <div class="col-1">
        <label for="username">Email</label><br>
        <input type="email" id="usernam" name="username"><br>
        <span id="usererr" style="color: #e6130c; font-size: 15px;"><?php echo $nameerror; ?></span>
    </div>
    <div class="col-1">
        <label for="password">Password</label><br>
        <input type="password" id="passwor" name="password"><br>
        <span id="passerr" style="color: #e6130c; font-size: 15px;"><?php echo $passworderror; ?></span><br>
        <a href="#forgot" onclick="myFunction4()"><h4>Forgot password?</h4></a>
    </div>
    <div class="col-1">
        <input type="submit" id="submit" name="submit" value="Login"><br>
        <span id="validerr" style="color: #e6130c; font-size: 15px;"><?php echo $invaliderror; ?></span><br>
       
    </div>
    <div class="col-1">
        <h3>Are you new? <a href="#register" onclick="myFunction2()">Create an account</a></h3>
    </div>
</form>

        </div>
    
    </div>
    </div>  
</div>

<script>





    document.getElementById("usernam").addEventListener("keyup", myFun);
    document.getElementById("passwor").addEventListener("keyup", myFun);

function myFun(){



   let usernam = document.getElementById("usernam").value;
   let passwor= document.getElementById("passwor").value;

   if((usernam=="")){
 
 document.getElementById("usererr").innerHTML=  
" plz enter username  ";  
status=false;
} 
else if((usernam.length<5)){
 
 document.getElementById("usererr").innerHTML=  
" atleast five character  ";  
status=false;  
}
else{  
document.getElementById("usererr").innerHTML="";  
status=true;  
}  
if((passwor=="")){
 
 document.getElementById("passerr").innerHTML=  
" plz enter password  ";  
status=false;
} 
else{


document.getElementById("passerr").innerHTML="";  
status=true;  


}


}






</script>
    <!--forgot password-->
    <div id="forgot">
    <div class="row">
        <div class="col-25">
        
        <img src="../image/img18-removebg-preview.png">
        
        
        </div>
        <div class="col-50">
            <div class="right">
              <h1>
              
              </h1>
        
                <form  method="post" action="../../controler/userResponce.php">
                    <div class="col-1">
                     <h3 class="h31"> Forgot Password</h3><br>
               <label for="user" id="text1">Enter your email we will send you a link to reset  your password</label><br>
              
        </div>
        <div class="col-1">
            
            <input type="email" id="email" name="email" placeholder="@gmail.com"><br>
            <span id="h51" style='color: #e6130c; font-size:15px;'>
            </span>
        </div>
        <div class="col-1">
           
            <input type="submit" id="submit3" name="submit" value="Resetpassword" ><br>
        <h5>or</h5>
        </div>
        <div class="col-1">
          <i class="fa-solid fa-backward fa-flip-vertical fa-xs" style="color: #74C0FC;"></i>    <a href="#login"onclick="myFunction3()">Back to login</a>
        </div>
                </form>
                <script>





                    document.getElementById("email").addEventListener("keyup", myFun1);
function myFun1(){


    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    let email = document.getElementById("email").value;

    if((email=="")){
 
 document.getElementById("h51").innerHTML=  
" plz enter email";  
status=false;
} 
else if(email.match(validRegex))
{
document.getElementById("h51").innerHTML=  
" <i style='color: #5ec44a;'>Valid email address</i>";  
status=false;
}
else{

    document.getElementById("h51").innerHTML=  
"plz enter email format";  
status=false;


}
}
        </script>
            </div>
        
        </div>
        </div>
        </div>
        
</div>

</body>

</html>