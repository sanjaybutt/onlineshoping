

<?php 
include '../../controler/userController.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sara</title>
    <style>
    .card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;

  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
.right {
  display: flex;
  flex-wrap: wrap;
  width: 70%;
  justify-content: center;
  margin: auto;
}

.card{
  flex: 1 0 300px;

margin-top:20px;
  min-height: 80px;
}
img:hover {
  -webkit-transform: scaleX(-1);
  transform: scaleX(-1);
}


    </style>


</head>
<body>
    <div class="container">
<?php  include 'code.php';

?> 
<navi>

<ul  class="nav">
<li><a href="womencollection">𝚃𝚘𝚙𝚜</a></li>
<li><a href="womencollection">𝚃𝚜𝚑𝚒𝚛𝚝𝚜</a></li>
<li><a href="womencollection">𝙺𝚞𝚛𝚝𝚊𝚜</a></li>
<li><a href="womencollection">𝙿𝚊𝚗𝚝𝚜</a></li>
</ul>

</navi>
</div>
<div class="right">
    <?php foreach ($alldata as $admin): ?>
     <?php if( $admin['categryid']==2){?>
        <div class="card">
            <a href="view?proid=<?= $admin['id'] ?>">
                <img src="../image/<?= $admin['pimage'] ?>" alt="<?= $admin['pimage'] ?>" width="100%" height="300px">
            </a>
            <h4><?= $admin['pname'] ?></h4>
            <p class="price">RS: <?= $admin['prize'] ?></p>
        </div>
        <?php  }  ?>
    <?php endforeach; ?>
</div>
</body>
</html>