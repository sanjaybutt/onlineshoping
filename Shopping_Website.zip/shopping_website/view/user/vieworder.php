

<?php 
include '../../controler/userController.php';
?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>sara</title>
    <style>
        body{
background-color:#F4ECF7;

        }
        table,
        th,
        td {
            border-collapse: collapse;
            border-bottom: 1px solid #EAEDED ;
        }

        table {
            width: 50%;
             margin-left:200px;
        }

        th,
        td {
            text-align: center;
        }
.dataview{
    
margin-top:40px;

}
        .table1 {
           float:right;
            
        }
        .container{
width:50%;
background-color:#EBDEF0 ;
margin-left:500px;
border-top-right-radius: 25px;
border-bottom-left-radius: 25px;
        }
        button{

background-color:#85C1E9; 
border:none;
padding:10px;
border-radius:5px;

        }
    </style>
</head>
<body>
<div class="container">
<h2>Your Produts!</h2>
<?php

if (!empty($rows)) {
    foreach ($rows as $row) {
      


       

       

        ?>
      
        <div class="dataview">
            
            <table>
            
                <tr>
                    
                    <td><img src="../<?= $row['pimage'] ?>" alt="Profile Picture" width="50" height="50"/></td>
                    <td><?= $row['pname'] ?></td>
                    <td><?= $row['qty'] ?></td>
                    <td>RS:<?= $row['prize'] ?></td>
                   <!-- <td><a href="../controler/code1.php?userid=<?= $row['id'] ?>&submit=delete"><i class="fa-solid fa-trash" style="color: #ed1219;"></i></a></td>-->
                </tr>
            </table> 
        </div>
        <?php
    }
    ?>
    
    <div class="table1">
        <table>
            <tr>
                <td>
                  
                </td>
            </tr>
            <tr>
             
</tr>
        </table>
    </div>
    <?php
} else {
   
    echo '<h2 style="margin-left:39%;">no order</h2>';
}
?>
 <div class="col-1">
          <i class="fa-solid fa-backward fa-flip-vertical fa-xs" style="color: #74C0FC;"></i>    <a href="checkpoint">Back to page</a>
        </div>
</div>
</body>
</html>
