
<?php 
include '../../controler/userController.php';
if (!isset($_SESSION['username']) || $_SESSION['username'] == "") {
    header('location:register');
    exit; 
}
?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>sara</title>
    <style>
        body{
background-color:#F4ECF7;

        }
        table,
        th,
        td {
            border-collapse: collapse;
            border-bottom: 1px solid #EAEDED ;
        }

        table {
            width: 50%;
             margin-left:200px;
        }

        th,
        td {
            text-align: center;
        }
.dataview{
    
margin-top:40px;

}
        .table1 {
           float:right;
            
        }
        .container{
width:50%;
background-color:#EBDEF0 ;
margin-left:500px;
border-top-right-radius: 25px;
border-bottom-left-radius: 25px;
        }
        button{

background-color:#85C1E9; 
border:none;
padding:10px;
border-radius:5px;

        }
    </style>
</head>
<body>
<div class="container">
    <div class="col-1">
        <a href="vieworder"><button>Your Orders</button></a>
    </div>

    <?php 
$shoppingCart = new ShoppingCart($link);

// Call the calculateTotal method to get the cart items and total
$result = $shoppingCart->calculateTotal($name);

// Retrieve cart items and total
$cartItems = $result['cartItems'];
$total = $result['total'];

?>


<?php if (!empty($total)): ?>
    <?php foreach ($cartItems as $item): ?>
        <div class="dataview">
            <table>
                <tr>
                    <td><img src="../<?= $item['pimage'] ?>" alt="Profile Picture" width="50" height="50"/></td>
                    <td><?= $item['pname'] ?></td>
                    <td><?= $item['qty'] ?></td>
                    <td>RS:<?= $item['prize'] ?></td>
                    <td><a href="../../controler/userResponce.php?userid=<?= $item['id'] ?>&submit=delete"><i class="fa-solid fa-trash" style="color: #ed1219;"></i></a></td>
                </tr>
            </table>
        </div>
    <?php endforeach; ?>

    <div class="table1">
        <table>
            <tr>
                <td>
                    <!-- Display the total -->
                    <h3>Total: <?= $total ?></h3>
                </td>
            </tr>
            <tr>
                <td><button><a href="orderdetails?id=<?= $item['id'] ?>">checkout</a></button></td>
            </tr>
        </table>
    </div>
<?php else: ?>
    <img src="../image/download.png" style="margin-left:40%;">
    <h2 style="margin-left:39%;">Your Cart Is Empty!</h2>
<?php endif; ?>


    <div class="col-1">
        <i class="fa-solid fa-backward fa-flip-vertical fa-xs" style="color: #74C0FC;"></i>
        <a href="index1">Back to page</a>
    </div>
</div>

</body>
</html>
